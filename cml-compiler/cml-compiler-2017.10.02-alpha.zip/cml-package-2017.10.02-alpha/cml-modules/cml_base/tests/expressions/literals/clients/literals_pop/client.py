
from cml_expressions_literals_pop import *

expressions = LiteralExpressions()

print("Expression Literals\n")

print("literal_true_boolean = %s" % expressions.literal_true_boolean)
print("literal_false_boolean = %s" % expressions.literal_false_boolean)
print("literal_string_init = %s" % expressions.literal_string_init)
print("literal_integer_init = %d" % expressions.literal_integer_init)
print("literal_decimal_init = %.3f" % expressions.literal_decimal_init)
print("literal_decimal_init_2 = %.3f" % expressions.literal_decimal_init_2)
